jQuery(document).ready( function(){

  $('#brand').removeClass('hidden');
  $('#brand').addClass('animated zoomInDown');

  $('#button, #heading').removeClass('hidden');
  $('#button, #heading').addClass('animated zoomIn');

  $('#main-nav, #social-media').removeClass('hidden');
  $('#main-nav, #social-media').addClass('animated fadeIn');

  $('#scroll-indicator').removeClass('hidden');
  $('#scroll-indicator').addClass('animated bounce');

});
