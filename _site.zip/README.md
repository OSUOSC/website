# The Open Source Club at The Ohio State University Website


# Repositories Used
- [Jekyll](https://github.com/jekyll/jekyll "Jekyll")
- [Jekyll-Assets](https://github.com/ixti/jekyll-assets "Jekyll-Assets")
- [Skel](https://github.com/n33/skel "Skel")
- [Font Awesome](https://github.com/FortAwesome/Font-Awesome "Font Awesome")
- [Hint.css](https://github.com/chinchang/hint.css "Hint.css")

